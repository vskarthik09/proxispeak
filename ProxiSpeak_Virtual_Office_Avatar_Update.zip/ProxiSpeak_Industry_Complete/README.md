# ProxiSpeak — Geospatial Proximity Audio Ecosystem

A full-stack starter implementation inspired by the supplied project brief. It includes email/password authentication, meeting creation and joining, audio/video calling, WebRTC screen sharing, chat, raise hand, live participant count, room types, avatar presence, a virtual office map, proximity-aware audio hooks, and optional message translation.

## Stack
- Frontend: React + Vite
- Backend: Node.js + Express + Socket.IO
- Database: MongoDB + Mongoose
- Realtime media: browser WebRTC peer connections (mesh)
- Authentication: bcrypt + JWT

## Requirements
- Node.js 20+
- MongoDB 7+ (local or hosted)
- Modern browser with camera/microphone permissions

## Quick start
1. Copy `backend/.env.example` to `backend/.env` and set `JWT_SECRET` and `MONGODB_URI`.
2. Install dependencies:
   ```bash
   cd backend && npm install
   cd ../frontend && npm install
   ```
3. Start MongoDB.
4. Start the API/realtime server:
   ```bash
   cd backend && npm run dev
   ```
5. In another terminal start the frontend:
   ```bash
   cd frontend && npm run dev
   ```
6. Open the Vite URL (normally http://localhost:5173), create an account, then create or join a meeting.

## Optional multi-server scaling
Set `REDIS_URL` in `backend/.env` to enable the Socket.IO Redis Pub/Sub adapter across multiple backend instances. Leave it blank for a single-server local demo. Use an SFU for scalable media forwarding; Redis alone does not make peer-to-peer video mesh scale to large rooms.

## Docker MongoDB
From the project root:
```bash
docker compose up -d mongo
```

## Environment
`backend/.env.example` documents the server settings. For translation, configure `LIBRETRANSLATE_URL` and optionally `LIBRETRANSLATE_API_KEY`. If no translation provider is configured, the UI reports that translation is unavailable rather than pretending to translate.

## Features
- Register/login with email and password; password hashes are stored with bcrypt.
- Create a meeting with a title and room type: Voice Call, Meeting Room, Lounge Room, or Conference Room.
- Join using a meeting ID; room membership and live participant count are broadcast over Socket.IO.
- Camera/microphone toggles, local preview, remote participant tiles, and WebRTC offer/answer/ICE signaling.
- Share/stop sharing the browser tab, window, or screen (browser permission required).
- In-room chat, hand-raise state, participant roster, and host controls.
- Selectable illustrated avatars and a live Canvas-based virtual office with movable avatar markers.\n- MongoDB GeoJSON `2dsphere` presence index, `$near` proximity query, and `$geoWithin` virtual-area query.
- Optional Socket.IO Redis Pub/Sub adapter for multi-instance signaling fan-out.\n- Web Audio API spatial mixer with distance-based gain attenuation and left/right stereo panning.
- Optional text translation through a configured LibreTranslate-compatible endpoint.

## Important engineering notes
This is a runnable full-stack project foundation, not a hosted production deployment. WebRTC currently uses a peer-to-peer mesh for straightforward local/demo operation. The live roster/count is stored in MongoDB and broadcast room-wide (including Redis-connected API instances). Mesh bandwidth and CPU grow rapidly with participant count; for reliable 50+ person rooms, replace the mesh media layer with an SFU such as LiveKit, mediasoup, or Janus, and deploy TURN servers. The participant count is realtime and is not a claim that every browser can sustain unlimited media streams.

For production: use HTTPS/WSS, a strong secret manager, email verification/password reset, rate limiting, CSRF/origin controls, audit logging, database backups, TURN credentials, SFU capacity planning, observability, and a managed translation provider. The default app is intended for development and evaluation.

## Project structure
```text
ProxiSpeak_Industry_Complete/
  backend/
    src/
      config/  middleware/  models/  routes/  realtime/
    .env.example  package.json
  frontend/
    src/
      components/  lib/
    index.html  package.json  vite.config.js
  docker-compose.yml
  README.md
```
